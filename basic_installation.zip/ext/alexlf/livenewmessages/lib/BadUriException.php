<?php

namespace WebSocket;
class BadUriException extends Exception {}
